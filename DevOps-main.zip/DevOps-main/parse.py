import parser
import hashlib
File "./app.py"
code = parsing.compile()
print(data)
res = eval(data)
print(res)
data = res.open(r "files/{id}+.txt", "W+")
try:
hashlib.sha256({data.id}=='{id}+txt').hexdigest()
else:
     print("Is not match")
 